; inherits: javascript
